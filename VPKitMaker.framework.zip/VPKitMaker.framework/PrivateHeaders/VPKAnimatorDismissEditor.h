//
//  VPKAnimatorDismissEditor.h
//  VPKit
//
//  Created by jonathan on 29/05/2016.
//  Copyright © 2016 jonathan. All rights reserved.
//

#import <VPKit/VPKit.h>
#import "VPKAnimatorBase.h"

@interface VPKAnimatorDismissEditor : VPKAnimatorBase

@end
