//
//  VPKPreview_Maker.h
//  VPKitMaker
//
//  Created by jonathan on 05/03/2018.
//  Copyright © 2018 jonathan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VPKit/VPKPreview.h>
#import "VPKVeepEditor.h"

@interface VPKPreview (Maker) <VPKVeepEditorDelegate>

@end
