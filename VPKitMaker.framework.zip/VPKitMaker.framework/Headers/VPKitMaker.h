//
//  VPMaker.h
//  VPMaker
//
//  Created by jonathan on 24/02/2018.
//  Copyright © 2018 jonathan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VPKitMaker.
FOUNDATION_EXPORT double VPKitMakerVersionNumber;

//! Project version string for VPKitMaker.
FOUNDATION_EXPORT const unsigned char VPKitMakerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VPMaker/PublicHeader.h>


#import <VPKitMaker/VPKVeepEditor.h>
#import <VPKitMaker/VPKitMakerClass.h>
#import <VPKitMaker/VPKPreview_Maker.h>
